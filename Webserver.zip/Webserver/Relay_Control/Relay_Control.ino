#include <WiFi.h>
#include <WebServer.h>

const char* ssid = "Krishna";
const char* password = "87654321";

#define RELAY_PIN 5

WebServer server(80);

bool relayState = false;


/* ------------ HTML PAGE ------------ */
String webpage = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
<title>ESP32 Relay Control</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
body{
  font-family: Arial;
  text-align:center;
  background: linear-gradient(135deg,#11998e,#38ef7d);
  margin-top:120px;
  color:white;
}

.card{
  background:white;
  color:black;
  padding:40px;
  border-radius:20px;
  display:inline-block;
  box-shadow:0 10px 25px rgba(0,0,0,0.3);
}

button{
  padding:15px 45px;
  font-size:20px;
  border:none;
  border-radius:30px;
  cursor:pointer;
  transition:0.3s;
}

.on{
  background:#27ae60;
  color:white;
}

.off{
  background:#e74c3c;
  color:white;
}

button:hover{
  transform:scale(1.1);
}

h1{
  margin-bottom:25px;
}
</style>
</head>

<body>

<div class="card">
<h1>ESP32 Relay Control </h1>

<p id="status">Relay is OFF</p>

<button id="toggleBtn" class="off" onclick="toggleRelay()">Turn ON</button>

</div>

<script>
function toggleRelay(){
  fetch("/toggle")
  .then(response => response.text())
  .then(state => {

    let btn = document.getElementById("toggleBtn");
    let status = document.getElementById("status");

    if(state == "ON"){
        btn.innerHTML = "Turn OFF";
        btn.className = "on";
        status.innerHTML = "Relay is ON";
    }
    else{
        btn.innerHTML = "Turn ON";
        btn.className = "off";
        status.innerHTML = "Relay is OFF";
    }
  });
}
</script>

</body>
</html>
)rawliteral";
/* ----------------------------------- */


void handleRoot() {
  server.send(200, "text/html", webpage);
}


// Toggle relay
void handleToggle() {

  relayState = !relayState;

  digitalWrite(RELAY_PIN, relayState);

  if (relayState)
    server.send(200, "text/plain", "ON");
  else
    server.send(200, "text/plain", "OFF");
}


void setup() {

  Serial.begin(115200);

  pinMode(RELAY_PIN, OUTPUT);
  digitalWrite(RELAY_PIN, LOW);

  WiFi.begin(ssid, password);
  Serial.print("Connecting");

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nConnected!");
  Serial.print("IP Address: ");
  Serial.println(WiFi.localIP());

  server.on("/", handleRoot);
  server.on("/toggle", handleToggle);

  server.begin();
}


void loop() {
  server.handleClient();
}
