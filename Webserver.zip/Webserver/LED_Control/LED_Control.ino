#include <WiFi.h>
#include <WebServer.h>

const char* ssid = "Krishna";
const char* password = "87654321";

#define LED_PIN 13   // Inbuilt LED or external LED

WebServer server(80);

bool ledState = false;   // OFF initially

/* ---------- HTML Webpage ---------- */
String webpage = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
<title>ESP32 LED Control</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
body{
  font-family: Arial;
  text-align:center;
  background: linear-gradient(135deg,#667eea,#764ba2);
  color:white;
  margin-top:120px;
}

.card{
  background:white;
  color:black;
  display:inline-block;
  padding:40px;
  border-radius:20px;
  box-shadow:0 10px 25px rgba(0,0,0,0.3);
}

button{
  padding:15px 40px;
  font-size:20px;
  border:none;
  border-radius:30px;
  cursor:pointer;
  transition:0.3s;
}

.on{
  background:#2ecc71;
  color:white;
}

.off{
  background:#e74c3c;
  color:white;
}

button:hover{
  transform:scale(1.1);
}

h1{
  margin-bottom:25px;
}
</style>
</head>

<body>

<div class="card">
<h1>ESP32 LED Control</h1>

<p id="status">LED is OFF</p>

<button id="toggleBtn" class="off" onclick="toggleLED()">Turn ON</button>
</div>

<script>
function toggleLED(){
  fetch("/toggle")
  .then(response => response.text())
  .then(state => {

    let btn = document.getElementById("toggleBtn");
    let status = document.getElementById("status");

    if(state == "ON"){
        btn.innerHTML = "Turn OFF";
        btn.className = "on";
        status.innerHTML = "LED is ON";
    }
    else{
        btn.innerHTML = "Turn ON";
        btn.className = "off";
        status.innerHTML = "LED is OFF";
    }
  });
}
</script>

</body>
</html>
)rawliteral";
/* ---------------------------------- */


// Serve webpage
void handleRoot() {
  server.send(200, "text/html", webpage);
}


// Toggle LED
void handleToggle() {
  ledState = !ledState;
  digitalWrite(LED_PIN, ledState);

  if (ledState)
    server.send(200, "text/plain", "ON");
  else
    server.send(200, "text/plain", "OFF");
}


void setup() {
  Serial.begin(115200);

  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  WiFi.begin(ssid, password);
  Serial.print("Connecting");

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nConnected!");
  Serial.print("IP Address: ");
  Serial.println(WiFi.localIP());

  server.on("/", handleRoot);
  server.on("/toggle", handleToggle);

  server.begin();
}

void loop() {
  server.handleClient();
}
