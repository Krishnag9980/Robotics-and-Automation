#include <WiFi.h>
#include <WebServer.h>

/* ---------- WiFi ---------- */
const char* ssid = "Krishna";
const char* password = "87654321";

/* ---------- Pins ---------- */
#define LED_PIN     13
#define BUZZER_PIN  35
#define RELAY_PIN   5

WebServer server(80);

/* ---------- States ---------- */
bool ledState = false;
bool buzzerState = false;
bool relayState = false;


/* ------------ HTML PAGE ------------ */
String webpage = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
<title>ESP32 Smart Control Panel</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>

body{
  font-family: Arial;
  text-align:center;
  background: linear-gradient(135deg,#667eea,#764ba2);
  color:white;
}

h1{
  margin-top:30px;
}

.container{
  display:flex;
  justify-content:center;
  gap:30px;
  flex-wrap:wrap;
  margin-top:50px;
}

.card{
  background:white;
  color:black;
  padding:30px;
  border-radius:20px;
  width:220px;
  box-shadow:0 10px 25px rgba(0,0,0,0.3);
}

button{
  padding:12px 30px;
  font-size:18px;
  border:none;
  border-radius:25px;
  cursor:pointer;
  transition:0.3s;
  margin-top:15px;
}

.on{
  background:#27ae60;
  color:white;
}

.off{
  background:#e74c3c;
  color:white;
}

button:hover{
  transform:scale(1.1);
}

.status{
  font-weight:bold;
  margin-top:10px;
}

</style>
</head>


<body>

<h1>ESP32 Smart Home Dashboard </h1>

<div class="container">

  <!-- LED -->
  <div class="card">
    <h2>  LED</h2>
    <p id="ledStatus" class="status">OFF</p>
    <button id="ledBtn" class="off" onclick="toggleDevice('led')">Turn ON</button>
  </div>

  <!-- Buzzer -->
  <div class="card">
    <h2>  Buzzer</h2>
    <p id="buzzerStatus" class="status">OFF</p>
    <button id="buzzerBtn" class="off" onclick="toggleDevice('buzzer')">Turn ON</button>
  </div>

  <!-- Relay -->
  <div class="card">
    <h2>  Relay</h2>
    <p id="relayStatus" class="status">OFF</p>
    <button id="relayBtn" class="off" onclick="toggleDevice('relay')">Turn ON</button>
  </div>

</div>


<script>

function toggleDevice(device){

  fetch("/" + device)
  .then(res => res.text())
  .then(state => {

    let btn = document.getElementById(device+"Btn");
    let status = document.getElementById(device+"Status");

    if(state == "ON"){
        btn.innerHTML = "Turn OFF";
        btn.className = "on";
        status.innerHTML = "ON";
    }
    else{
        btn.innerHTML = "Turn ON";
        btn.className = "off";
        status.innerHTML = "OFF";
    }

  });
}

</script>

</body>
</html>
)rawliteral";
/* ----------------------------------- */


/* ---------- Handlers ---------- */

void handleRoot() {
  server.send(200, "text/html", webpage);
}

void toggleLED() {
  ledState = !ledState;
  digitalWrite(LED_PIN, ledState);
  server.send(200, "text/plain", ledState ? "ON" : "OFF");
}

void toggleBuzzer() {
  buzzerState = !buzzerState;
  digitalWrite(BUZZER_PIN, buzzerState);
  server.send(200, "text/plain", buzzerState ? "ON" : "OFF");
}

void toggleRelay() {
  relayState = !relayState;

  // If relay is active LOW, change to !relayState
  digitalWrite(RELAY_PIN, relayState);

  server.send(200, "text/plain", relayState ? "ON" : "OFF");
}


/* ---------- Setup ---------- */

void setup() {

  Serial.begin(115200);

  pinMode(LED_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(RELAY_PIN, OUTPUT);

  digitalWrite(LED_PIN, LOW);
  digitalWrite(BUZZER_PIN, LOW);
  digitalWrite(RELAY_PIN, LOW);

  WiFi.begin(ssid, password);
  Serial.print("Connecting");

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nConnected!");
  Serial.println(WiFi.localIP());

  server.on("/", handleRoot);
  server.on("/led", toggleLED);
  server.on("/buzzer", toggleBuzzer);
  server.on("/relay", toggleRelay);

  server.begin();
}


/* ---------- Loop ---------- */

void loop() {
  server.handleClient();
}
