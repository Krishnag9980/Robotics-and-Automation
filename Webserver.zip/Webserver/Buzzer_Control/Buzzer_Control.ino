#include <WiFi.h>
#include <WebServer.h>

const char* ssid = "Krishna";
const char* password = "87654321";

#define BUZZER_PIN 6     // Buzzer connected here

WebServer server(80);

bool buzzerState = false;


/* ---------- HTML PAGE ---------- */
String webpage = R"rawliteral(
<!DOCTYPE html>
<html>
<head>
<title>ESP32 Buzzer Control</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
body{
  font-family: Arial;
  text-align:center;
  background: linear-gradient(135deg,#ff9966,#ff5e62);
  margin-top:120px;
  color:white;
}

.card{
  background:white;
  color:black;
  padding:40px;
  border-radius:20px;
  display:inline-block;
  box-shadow:0 10px 25px rgba(0,0,0,0.3);
}

button{
  padding:15px 40px;
  font-size:20px;
  border:none;
  border-radius:30px;
  cursor:pointer;
  transition:0.3s;
}

.on{
  background:#27ae60;
  color:white;
}

.off{
  background:#c0392b;
  color:white;
}

button:hover{
  transform:scale(1.1);
}

h1{
  margin-bottom:25px;
}
</style>
</head>

<body>

<div class="card">
<h1>ESP32 Buzzer Control</h1>

<p id="status">Buzzer is OFF</p>

<button id="toggleBtn" class="off" onclick="toggleBuzzer()">Turn ON</button>

</div>

<script>
function toggleBuzzer(){
  fetch("/toggle")
  .then(response => response.text())
  .then(state => {

    let btn = document.getElementById("toggleBtn");
    let status = document.getElementById("status");

    if(state == "ON"){
        btn.innerHTML = "Turn OFF";
        btn.className = "on";
        status.innerHTML = "Buzzer is ON";
    }
    else{
        btn.innerHTML = "Turn ON";
        btn.className = "off";
        status.innerHTML = "Buzzer is OFF";
    }
  });
}
</script>

</body>
</html>
)rawliteral";
/* -------------------------------- */


// Serve page
void handleRoot() {
  server.send(200, "text/html", webpage);
}


// Toggle buzzer
void handleToggle() {
  buzzerState = !buzzerState;
  digitalWrite(BUZZER_PIN, buzzerState);

  if (buzzerState)
    server.send(200, "text/plain", "ON");
  else
    server.send(200, "text/plain", "OFF");
}


void setup() {
  Serial.begin(115200);

  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);

  WiFi.begin(ssid, password);
  Serial.print("Connecting");

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nConnected!");
  Serial.print("IP Address: ");
  Serial.println(WiFi.localIP());

  server.on("/", handleRoot);
  server.on("/toggle", handleToggle);

  server.begin();
}

void loop() {
  server.handleClient();
}
