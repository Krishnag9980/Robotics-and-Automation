#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <UniversalTelegramBot.h>
#include "DHT.h"

// 🔐 WiFi Credentials
const char* ssid = "Krishna";
const char* password = "987654321";

// 🤖 Telegram Details
String BOT_TOKEN = "8722323489:AAHtZqN6V0nOrwvwqxi4pZzX14N6aDohBKQ";
String CHAT_ID  =  "8465766689";


WiFiClientSecure client;
UniversalTelegramBot bot(BOT_TOKEN, client);

// 🌡️ DHT Settings
#define DHTPIN 4
#define DHTTYPE DHT11
DHT dht(DHTPIN, DHTTYPE);

// ⚠️ Thresholds
float tempThreshold = 30.0;
float humThreshold  = 70.0;

// ⏱️ Cooldown Timer (2 minutes)
unsigned long lastAlertTime = 0;
unsigned long alertInterval = 120000;

// 📩 Telegram polling
unsigned long lastTimeChecked = 0;
const unsigned long checkInterval = 2000;

void setup() {
  Serial.begin(115200);
  dht.begin();

  // 🔐 HTTPS Fix
  client.setInsecure();

  WiFi.begin(ssid, password);
  Serial.print("Connecting to WiFi");

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nWiFi Connected ✅");
}

// 📩 Handle Telegram Commands
void handleMessages(int numNewMessages) {
  Serial.println("Checking Telegram Messages...");

  for (int i = 0; i < numNewMessages; i++) {

    String chat_id = String(bot.messages[i].chat_id);
    String text = bot.messages[i].text;

    Serial.println(text);

    // 🔒 Allow only your chat ID
    if (chat_id != CHAT_ID) {
      bot.sendMessage(chat_id, "Unauthorized user", "");
      continue;
    }

    // 📊 /status command
    if (text == "/status") {

      float temp = dht.readTemperature();
      float hum  = dht.readHumidity();

      String msg = "📊 Current Status\n";
      msg += "🌡 Temp: " + String(temp) + " C\n";
      msg += "💧 Hum: " + String(hum) + " %";

      bot.sendMessage(chat_id, msg, "");
    }

    // 👋 /start command
    if (text == "/start") {
      String welcome = "Welcome Boss 😎\n";
      welcome += "Use command:\n";
      welcome += "/status → Get live sensor data";
      bot.sendMessage(chat_id, welcome, "");
    }
  }
}

void loop() {

  float temp = dht.readTemperature();
  float hum  = dht.readHumidity();

  if (isnan(temp) || isnan(hum)) {
    Serial.println("DHT Read Failed ❌");
    return;
  }

  Serial.print("Temp: ");
  Serial.print(temp);
  Serial.print(" °C | Hum: ");
  Serial.println(hum);

  // 🚨 Cooldown Alert Logic
  if ((temp > tempThreshold || hum > humThreshold) &&
      (millis() - lastAlertTime > alertInterval)) {

    String message = "🚨 ALERT!\n";
    message += "🌡 Temp: " + String(temp) + " C\n";
    message += "💧 Hum: " + String(hum) + " %";

    bot.sendMessage(CHAT_ID, message, "");
    Serial.println("Alert Sent ✅");

    lastAlertTime = millis();
  }

  // 📩 Check Telegram Messages
  if (millis() - lastTimeChecked > checkInterval) {

    int numNewMessages = bot.getUpdates(bot.last_message_received + 1);

    while (numNewMessages) {
      handleMessages(numNewMessages);
      numNewMessages = bot.getUpdates(bot.last_message_received + 1);
    }

    lastTimeChecked = millis();
  }

  delay(2000);
}