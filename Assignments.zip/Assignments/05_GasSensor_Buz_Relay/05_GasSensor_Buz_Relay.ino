//WAP for Gas Sensor when threashold cross then turn on Buzzer and Relay

// -------- Pin Definitions --------
#define MQ2_PIN     34
#define BUZZER_PIN  4
#define RELAY_PIN   5
int threshold = 1500;   // Gas limit

void setup() {

  pinMode(MQ2_PIN, INPUT);      // <-- Important for students
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(RELAY_PIN, OUTPUT);
  Serial.begin(9600);
}
void loop() {

  int gasValue = analogRead(MQ2_PIN);

  Serial.print("Gas Value: ");
  Serial.println(gasValue);
  if (gasValue > threshold) {

    digitalWrite(BUZZER_PIN, HIGH);   // Alarm ON
    digitalWrite(RELAY_PIN, HIGH);

  }
  else {

    digitalWrite(BUZZER_PIN, LOW);    // Alarm OFF
    digitalWrite(RELAY_PIN, LOW);

  }

  delay(500);
}
