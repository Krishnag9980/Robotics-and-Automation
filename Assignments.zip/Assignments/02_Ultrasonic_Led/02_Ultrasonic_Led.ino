// -------- Pin Definitions --------
#define TRIG_PIN 5
#define ECHO_PIN 18
#define LED_PIN  2

// -------- Setup --------
void setup() {

  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  pinMode(LED_PIN, OUTPUT);
  
  Serial.begin(9600);
}
// -------- Loop --------
void loop() {

  // Send trigger pulse
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);

  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  // Read echo time
 long duration = pulseIn(ECHO_PIN, HIGH);

  // Convert to distance (cm)
  float distance = duration * 0.034 / 2;

  Serial.print("Distance: ");
  Serial.print(distance);
  Serial.println(" cm");


  // -------- Condition --------
  if (distance <= 2) {
    digitalWrite(LED_PIN, HIGH);   // LED ON
  }
  else {
    digitalWrite(LED_PIN, LOW);    // LED OFF
  }

  delay(200);
}
