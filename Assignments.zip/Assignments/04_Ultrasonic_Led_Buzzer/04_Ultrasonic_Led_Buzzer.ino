// -------- Pin Definitions --------
#define TRIG_PIN    5
#define ECHO_PIN    18
#define LED_PIN     2
#define BUZZER_PIN  4


// -------- Setup --------
void setup() {

  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  pinMode(LED_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  Serial.begin(9600);
}


// -------- Loop --------
void loop() {

  // Send ultrasonic pulse
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);

  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  // Measure echo time
 long duration = pulseIn(ECHO_PIN, HIGH);

  // Convert time to distance
float distance = duration * 0.034 / 2;

  Serial.print("Distance: ");
  Serial.print(distance);
  Serial.println(" cm");


  // -------- If-Else Ladder --------
  if (distance <= 3) {

    digitalWrite(LED_PIN, HIGH);      // LED ON
    digitalWrite(BUZZER_PIN, LOW);   // Buzzer OFF

  }
  else if (distance >= 4 && distance <= 7) {

    digitalWrite(LED_PIN, LOW);      // LED OFF
    digitalWrite(BUZZER_PIN, HIGH);  // Buzzer ON

  }
  else {

    digitalWrite(LED_PIN, LOW);      // Both OFF
    digitalWrite(BUZZER_PIN, LOW);

  }

  delay(200);
}
