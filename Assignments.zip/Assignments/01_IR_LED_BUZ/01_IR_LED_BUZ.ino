// -------- Pin Definitions --------
#define IR_PIN     15
#define LED_PIN    2
#define BUZZER_PIN 4
// -------- Setup --------
void setup() {

  pinMode(IR_PIN, INPUT);        // IR sensor input
  pinMode(LED_PIN, OUTPUT);     // LED output
  pinMode(BUZZER_PIN, OUTPUT);  // Buzzer output
  Serial.begin(9600);
}
// -------- Loop --------
void loop() {

  int sensorValue = digitalRead(IR_PIN);   // Read IR sensor

  if (sensorValue == LOW) {   // Object detected (Active LOW)

    digitalWrite(LED_PIN, HIGH);      // LED ON
    digitalWrite(BUZZER_PIN, LOW);   // Buzzer OFF
    Serial.println("Object Detected → LED ON, Buzzer OFF");

  }
  else {

    digitalWrite(LED_PIN, LOW);      // LED OFF
    digitalWrite(BUZZER_PIN, HIGH);  // Buzzer ON
    Serial.println("No Object → LED OFF, Buzzer ON");

  }

  delay(300);   // small delay
}
