#define touch 2

void setup() {
  // put your setup code here, to run once:
pinMode(touch, INPUT);
Serial.begin(9600);

}

void loop() {
  // put your main code here, to run repeatedly:
int value = digitalRead(touch);

if (value == HIGH) 
{
  
  Serial.println("Touch is detected");
}

else {
  Serial.println("Touch is not detected");

}
}
