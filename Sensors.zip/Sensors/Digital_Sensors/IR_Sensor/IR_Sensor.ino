// -------- Pin Definition --------
#define IR_PIN 7     // IR OUT connected to GPIO 15

// -------- Setup --------
void setup() {
  pinMode(IR_PIN, INPUT);   // Set IR pin as input
  Serial.begin(9600);       // Start serial monitor
}

// -------- Loop --------
void loop() {

  int sensorValue = digitalRead(IR_PIN);   // Read IR sensor

  if (sensorValue == LOW) {
    Serial.println("Object Detected");
  }
  else {
    Serial.println("No Object Detected");
  }

  delay(500);   // Small delay for stability
}
