#include <DHT.h>          // Include DHT library

DHT dht(4, DHT11);   // Create DHT object

// -------- Setup Function --------
void setup() {
  Serial.begin(9600);     // Start serial monitor
  dht.begin();            // Initialize DHT sensor
}

// -------- Loop Function --------
void loop() {

  // Read values
  float humidity = dht.readHumidity();
  float temperature = dht.readTemperature();

  // Print values neatly
  Serial.print("Humidity: ");
  Serial.print(humidity);
  Serial.print(" %   ");

  Serial.print("Temperature: ");
  Serial.print(temperature);
  Serial.println(" °C");

  delay(2000);   // Wait 2 seconds
}
