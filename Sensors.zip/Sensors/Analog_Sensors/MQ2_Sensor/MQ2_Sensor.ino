// -------- Pin Definition --------
#define MQ2_PIN A0     // Analog pin connected to MQ2

// -------- Variables --------
int gasValue = 0;
int threshold = 400;   // Change based on testing

void setup()
{
  Serial.begin(9600);

  pinMode(MQ2_PIN, INPUT);   // Good practice for students
}

void loop()
{
  // Read analog value (0–1023)
  gasValue = analogRead(MQ2_PIN);

  // Print sensor value
  Serial.print("Gas Value: ");
  Serial.println(gasValue);

  // Condition check
  if (gasValue > threshold)
  {
    Serial.println("⚠ Gas Detected!");
  }
  else
  {
    Serial.println("✅ Gas Not Detected");
  }

  delay(1000); // 1 second delay
}
