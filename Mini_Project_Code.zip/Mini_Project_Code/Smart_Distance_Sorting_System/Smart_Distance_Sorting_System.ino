#include <ESP32Servo.h>

// Ultrasonic pins
#define TRIG_PIN 7
#define ECHO_PIN 8

// Servo pin
#define SERVO_PIN 4

//Touch Pin
#define touch 2

Servo myServo;

// Function to measure distance
long getDistance() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);

  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  long duration = pulseIn(ECHO_PIN, HIGH);
  long distance = duration * 0.034 / 2; // cm

  return distance;
}

void setup() {
  Serial.begin(115200);

  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  myServo.attach(SERVO_PIN);

  //touch pin 
  pinMode(touch, INPUT);

}

void loop() {

  //Read Touch Sensor Value 
  int value = digitalRead(touch);

  //calculate distance
  long distance = getDistance();

  Serial.print("Distance: ");
  Serial.print(distance);
  Serial.println(" cm");

  // ---- Sorting Logic ----

  if (value == HIGH)
  {
  if (distance >= 3 && distance <= 5) {
    myServo.write(30);
    Serial.println("Object at 4cm → Servo 30°");
  }
  else if (distance >= 5 && distance <= 7) {
    myServo.write(90);
    Serial.println("Object at 6cm → Servo 90°");
  }
  else if (distance >= 9 && distance <= 11) {
    myServo.write(180);
    Serial.println("Object at 10cm → Servo 180°");
  }
  else if (distance >= 45 && distance <= 55) {
    myServo.write(120);
    Serial.println("Object at 50cm → Servo 120°");
  }
    Serial.println("Touch is Detected and System Started");
  }
else {
  
  Serial.println("Touch is not detected so System Stopped");

}

  delay(300);
}