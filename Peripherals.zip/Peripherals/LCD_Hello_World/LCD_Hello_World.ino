#include <Wire.h>
#include <LiquidCrystal_I2C.h>

// Set LCD address (common: 0x27 or 0x3F)
LiquidCrystal_I2C lcd(0x27, 16, 2);

// Define I2C pins for ESP32-S3
#define SDA_PIN 10
#define SCL_PIN 11

void setup() {
  // Initialize I2C with custom pins
  Wire.begin(SDA_PIN, SCL_PIN);

  // Initialize LCD
  lcd.init();
  lcd.backlight();

  // Print message
  lcd.setCursor(0, 0);
  lcd.print("Hello World");

  lcd.setCursor(0, 1);
  lcd.print("ESP32-S3 Ready");
}

void loop() {
  // Nothing required
}