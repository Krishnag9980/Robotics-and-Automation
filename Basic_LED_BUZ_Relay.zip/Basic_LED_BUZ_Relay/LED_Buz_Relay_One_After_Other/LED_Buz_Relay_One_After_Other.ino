//Program to Turn ON and OFF LED, Buzzer and Relay for one after the other

//Initialization 
int Led = 13;
int Buzzer = 35;
int Relay = 36;

void setup() {
  //Declaration LED, Buzzer and Relay as Output
  pinMode(Led, OUTPUT);
  pinMode(Buzzer, OUTPUT);
  pinMode(Relay, OUTPUT);

  }

void loop() {
  //Turn ON LED, for 3 Seconds
  digitalWrite(Led, HIGH);
  delay(3000);

// Turn ON Buzzer for half Seconds
  digitalWrite(Buzzer, HIGH);
  delay(500);

//Turn ON Relay for 1 Seconds
  digitalWrite(Relay, HIGH);
  delay(1000);


// TURN OFF LED , BUZZER and Relay One After the Other

  //Turn OFF LED, for 3 Seconds
  digitalWrite(Led, LOW);
  delay(3000);

// Turn OFF Buzzer for half Seconds
  digitalWrite(Buzzer, LOW);
  delay(500);

//Turn OFF Relay for 1 Seconds
  digitalWrite(Relay, LOW);
  delay(1000);

}
