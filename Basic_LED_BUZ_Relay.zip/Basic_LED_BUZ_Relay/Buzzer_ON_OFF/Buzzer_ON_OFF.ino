//Program to Turn ON and OFF Buzzer for 2 Seconds

//Initialization 
int buzzer = 6;

void setup() {
  //Declaration Buzzer as Output
  pinMode(buzzer, OUTPUT);

  }

void loop() {
  //Turn ON Buzzer for 2 Seconds
  digitalWrite(buzzer, HIGH);
  delay(2000);

  //Turn OFF buzzer for 2 Seconds
  digitalWrite(buzzer, LOW);
  delay(2000);

}
