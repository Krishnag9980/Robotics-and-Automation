//Program : Turn On Inbuilt LED ON and OFF for 2 Seconds : Led Pin = 4

// Initialization
int led = 4;

void setup() {
  // Declaration 
  pinMode(led, OUTPUT);
}

void loop() {
  // Led ON for 2 Seconds
digitalWrite(led, HIGH);
delay(2000);

// Led Off for 2 Seconds
digitalWrite(led, LOW);
delay(2000);

}
