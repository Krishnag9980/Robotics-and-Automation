#define BUTTON_PIN 4
#define BUZZER_PIN 6

void setup()
{
  pinMode(BUTTON_PIN, INPUT_PULLUP);  // internal pull-up
  pinMode(BUZZER_PIN, OUTPUT);

  Serial.begin(9600);
}

void loop()
{
  int buttonState = digitalRead(BUTTON_PIN);

  if(buttonState == LOW)   // pressed
  {
    digitalWrite(BUZZER_PIN, HIGH);
    Serial.println("Button Pressed - Buzzer ON");
  }
  else
  {
    digitalWrite(BUZZER_PIN, LOW);
  }
}
