//Program to Turn ON and OFF LED, Buzzer and Relay for 2 Seconds at a Time

//Initialization 
int Led = 13;
int Buzzer = 35;
int Relay = 5;

void setup() {
  //Declaration LED, Buzzer and Relay as Output
  pinMode(Led, OUTPUT);
  pinMode(Buzzer, OUTPUT);
  pinMode(Relay, OUTPUT);

  }

void loop() {
  //Turn ON LED, Buzzer and  Relay for 2 Seconds
  digitalWrite(Led, HIGH);
  digitalWrite(Buzzer, HIGH);
  digitalWrite(Relay, HIGH);
  delay(2000);

  //Turn OFF LED, Buzzer and Relay for 2 Seconds
  digitalWrite(Led, LOW);
  digitalWrite(Buzzer, LOW);
  digitalWrite(Relay, LOW);
  delay(2000);

}
